# Sign Language Project > 2025-04-25 6:18pm
https://universe.roboflow.com/aditis-workspace-qit5e/sign-language-project-ps2dh

Provided by a Roboflow user
License: CC BY 4.0

