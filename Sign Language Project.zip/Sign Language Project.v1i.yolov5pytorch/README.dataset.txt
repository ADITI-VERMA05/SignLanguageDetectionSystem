# Sign Language Project > 2025-04-13 5:35pm
https://universe.roboflow.com/aditis-workspace-qit5e/sign-language-project-ps2dh

Provided by a Roboflow user
License: CC BY 4.0

